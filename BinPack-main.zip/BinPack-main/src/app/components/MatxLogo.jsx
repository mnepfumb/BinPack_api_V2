const MatxLogo = ({ className }) => {

  return (
    <img src="/BinPack/assets/images/logo.png" width="84px" height="74px" alt="netcare" />
  );
};

export default MatxLogo;
